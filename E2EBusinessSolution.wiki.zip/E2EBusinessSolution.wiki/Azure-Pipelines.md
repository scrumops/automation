Continuous integration (CI) is the process of automating the build and testing of code every time a team member commits changes to version control.

<IMG  src="https://docs.microsoft.com/en-us/learn/azure-devops/create-a-build-pipeline/media/2-whiteboard-pipeline-with-callouts.png"  alt="A hand-drawn illustration of a CI pipeline"/>

**The differences between implementing hosted and private agents**

If your pipelines are in Azure Pipelines, then you've got a convenient option to build and deploy using a Microsoft-hosted agent. With Microsoft-hosted agents, maintenance and upgrades are taken care of for you. Each time you run a pipeline, you get a fresh virtual machine. The virtual machine is discarded after one use.

An agent that you set up and manage on your own to run build and deployment jobs is a self-hosted agent. You can use self-hosted agents in Azure Pipelines. Self-hosted agents give you more control and let you install any software you need for your builds and deployments.

Here are some examples of where you might need multiple parallel jobs.

- If you have multiple teams, and if each of them requires a CI build, you'll likely need a parallel job for each team.
- If your CI build trigger applies to multiple branches, you'll likely need a parallel job for each active branch.
- If you develop multiple applications by using one organization or server, you'll likely need additional parallel jobs, one to deploy each application at the same time.

- **For Map script commands to Azure Pipelines tasks**
https://docs.microsoft.com/en-us/azure/devops/pipelines/tasks/?view=azure-devops

- A template enables you to define common build tasks one time and reuse those tasks multiple times.
- In a template file, you use the parameters section instead of variables to define inputs.
- In a template file, you use ${{ }} syntax instead of $() to read a parameter's value. When you read a parameter's value, you include the parameters section in its name. For example, ${{ parameters.buildConfiguration }}.

**Expressions:**
https://docs.microsoft.com/en-us/azure/devops/pipelines/process/expressions?view=azure-devops#job-status-functions 
https://docs.microsoft.com/en-us/azure/devops/pipelines/process/conditions?view=azure-devops&tabs=classic