**Agile Project Management:**

Agile is a term that's used to describe approaches to software development, emphasizing incremental delivery, team collaboration, continual planning, and continual learning. Agile isn't a process as much as it is a philosophy or mindset for planning the work that a team will do. It's based on iterative development and helps a team better plan for and react to the inevitable changes that occur in software development. 


We value:

- Individuals and interactions over processes and tools
- Working software over comprehensive documentation
- Customer collaboration over contract negotiation
- Responding to change over following a plan

- [ ] Over time though, it's important for team members to develop an ability to mentor each other
- [ ] To give team members more control, meetings need an agenda and strict time frames.
- [ ] Cross-functional teams make the entire organization more cohesive

For more information- agile at scale please refer below:

<A  href="https://docs.microsoft.com/en-us/azure/devops/boards/plans/?view=azure-devops">https://docs.microsoft.com/en-us/azure/devops/boards/plans/?view=azure-devops</A>