
DevOps encourages teams to have goals that are specific, measurable, and time-bound. To ensure that these goals are measurable, it's important for the team to agree on appropriate metrics and Key Performance Indicators (KPIs). It's important to choose metrics that focus on specific business outcomes, and that achieve a return on investment and increased business value. Here is a list of commonly used metrics and KPIs that apply to all DevOps teams.

https://docs.microsoft.com/en-us/azure/devops/learn/ 
- **Faster Outcomes**
1. Deployment Frequency. Increasing the frequency of deployments is often a critical driver in DevOps teams.

       Response-

1. Deployment Speed. As well as increasing how often deployments happen, it's important to decrease the time that they take.

       Response-


1. Deployment Size. How many features, stories, and bug fixes are being deployed each time?

       Response-


1. Lead Time. How long does it take from starting on a work item, until it is deployed?

       Response-


- **Efficiency**
1. Server to Admin Ratio. Are the projects reducing the number of administrators required for a given number of servers?

       Response-


1. Staff Member to Customers Ratio. Is it possible for fewer staff members to serve a given number of customers?

       Response-


1. Application Usage. How busy is the application?

       Response-


1. Application Performance. Is the application performance improving or dropping? (Based upon application metrics.)

       Response-


- **Quality and Security**
1. Deployment Failure Rates. How often do deployments (and/or applications) fail?

       Response-


1. Application Failure Rates. How often do application failures occur, such as configuration failures, performance timeouts, and so on?

       Response-


1. Mean Time to Recover. How quickly can you recover from a failure?

       Response-


1. Bug Report Rates. You don't want customers finding bugs in your code. Is the amount they are finding increasing or decreasing?

       Response-


1. Test Pass Rates. How well is your automated testing working?

       Response-


1. Defect Escape Rate. What percentage of defects are being found in production?

       Response-


1. Availability. What percentage of time is the application truly available for customers?

       Response-


1. SLA Achievement. Are you meeting your service level agreements (SLAs)?

       Response-


1. Mean Time to Detection. If there is a failure, how long does it take for it to be detected?

       Response-


- **Culture**
1. Employee Morale. Are employees happy with the transformation and where the project scope is heading? Are they still willing to respond to further changes?
1. Retention Rates. Is the project scope losing staff?

       Response-


1. One of the promises of DevOps is to deliver software faster and with higher quality. It may seem that these promises are contradictory. Traditionally, the faster you delivered the software, the lower the quality. Higher-quality software always took longer. However, DevOps processes can help you to find problems earlier, and this usually means that they take less time to fix. Are we agree on these terms?

       Response-

- **Common quality metrics**
1. Failed Builds Percentage - Overall, what percentage of builds are failing?

       Response-


1. Failed Deployments Percentage - Overall, what percentage of deployments are failing?

       Response-


1. Ticket Volume - What is the overall volume of customer bug tickets?

       Response-


1. Bug Bounce Percentage - What percentage of customer or bug tickets are being reopened?

       Response-


1. Unplanned Work Percentage - What percentage of the overall work being performed is unplanned?

       Response-

